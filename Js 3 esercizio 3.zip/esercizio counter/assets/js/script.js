var n = sessionStorage.getItem('timer');
function timer () {
    if (n === null) {
        n = 0;
    }
    n++;
    sessionStorage.setItem("timer", n);
    document.getElementById('counter').innerHTML = `${n} secondi sono già passati`;
}

setInterval(timer, 1000)