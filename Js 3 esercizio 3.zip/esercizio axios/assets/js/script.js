axios.get('https://jsonplaceholder.typicode.com/users').then(function(response) {
    console.log(response);    
    console.table(response.data);
}).catch(function (error) {
    console.log(error);
})
axios.post('https://jsonplaceholder.typicode.com/users', {username: 'bot', email: 'fakeEmai@gmail.com'}).then(function(response) {   
    console.table(response.data);
}).catch(function (error) {
    console.log(error);
})
axios.put('https://jsonplaceholder.typicode.com/users/2', {username: 'botPut', email: 'fakePUTEmai@gmail.com'}).then(function(response) {   
    console.table(response.data);
}).catch(function (error) {
    console.log(error);
})