function aggiungiNome() {
    var x = document.getElementById("nome").value;
    var nome = localStorage.setItem("name", x);
    let leggiNome = localStorage.getItem("name")
    document.getElementById("benvenuto").innerHTML = `Benvenuto: ${leggiNome}`;
};

function rimuoviNome() {
    localStorage.clear();
    document.getElementById("benvenuto").innerHTML = `Benvenuto:`;
}